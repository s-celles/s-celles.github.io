---
title: Mise en place d'un environnement de calcul distribué dans un homelab
draft: false
---
## [[2.01. Présentation du homelab]]
## [[2.02. Mise en place de votre homelab]]
## [[2.03. Plan d'adressage IP]]
## [[2.04. Hyperviseur de type 1 et Proxmox Virtual Environnement]]

## [[2.05. Mise en place de la machine de déploiement]]
## [[2.06. Terraform, un outil pour l'IaC]]
## [[2.07. Ansible pour la gestion de configuration]]

## [[2.08. Retour sur notre projet d'exécution d'un calcul distribué avec Julia]]
